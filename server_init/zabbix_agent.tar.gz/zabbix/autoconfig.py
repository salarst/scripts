#!/usr/bin/python
import subprocess

p = subprocess.PIPE
subprocess.Popen('useradd -r zabbix',shell=True)
ret = subprocess.Popen(''' ip a s | grep eth | grep inet |awk  '{print $2}' | awk -F'/' '{print $1}' ''',shell=True,stdout=p,stdin=p,stderr=p)
ip = ret.stdout.read().strip('\n')
subprocess.Popen('chown -R zabbix.zabbix /data/apps/zabbix/logs',shell=True)

subprocess.Popen("sed -i 's#Hostname=192.168.1.144#Hostname=%s#g' /data/apps/zabbix/etc/zabbix_agentd.conf"%ip,shell=True)
subprocess.Popen("/bin/cp /data/apps/zabbix/zabbix_agent.service /usr/lib/systemd/system;systemctl daemon-reload;systemctl restart zabbix_agent;systemctl enable zabbix_agent",shell=True)
